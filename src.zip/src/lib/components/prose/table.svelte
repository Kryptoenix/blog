<div class='overflow-x-auto mb-4'>
  <table class='table w-full'>
    <slot />
  </table>
</div>
