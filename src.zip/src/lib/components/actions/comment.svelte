<button class="tooltip tooltip-left opacity-60 hover:opacity-100" data-tip="Jump to comments">
    <a href="#post-comment" class="btn btn-circle btn-ghost hover:bg-red-10">
      <span class="i-heroicons-outline-chat-alt-2" />
    </a>
  </button>