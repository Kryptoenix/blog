export interface Icon {
  sizes?: string
  src: string
  type?: string
}
